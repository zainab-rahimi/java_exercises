package com.phdareys.spr.entity;

public enum MealCateg {
	START, MAIN, DESSERT

}
