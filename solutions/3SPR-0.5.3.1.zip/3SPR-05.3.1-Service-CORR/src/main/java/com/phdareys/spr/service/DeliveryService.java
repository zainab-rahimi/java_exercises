package com.phdareys.spr.service;

import org.springframework.stereotype.Service;

@Service
public class DeliveryService {
	// un autre service!!
	public int getCost() {return 5;}

}
