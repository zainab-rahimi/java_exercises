package com.phdareys.bean;

import java.util.Iterator;
import java.util.List;

public class ManageList {
	private String name;  
	private List<String> answers;  
	  
	/* constructeur anonyme */
	public ManageList() {}  
	/* constructeur principal */
	public ManageList(String name, List<String> answers) {  
	    super();  
	    this.name = name;  
	    this.answers = answers;  
	}  
	  
	/* m�thode d'affichage, les propri�t�s sont charg�es par injection depuis le XML */
/*	public void displayInfo(){  
        System.out.println("\nList Display(ArrayList) -> " + 
        		name + ":");
	    System.out.println(" Possible answers:");  
	    Iterator<String> itr=answers.iterator();  
	    while(itr.hasNext()){  
	        System.out.println("\t---> " + itr.next());  
	    }  
	}*/
	@Override
	public String toString() {
		return "ManageList [name=" + name + ", answers=" + answers + "]";
	}  
}
