package com.phdareys.bean;

import java.util.HashMap;

public class Directory {
    private String name;
    private HashMap<String, String> hMap;
    
    public Directory(String name, HashMap<String, String> annuaire) {
        super();
        this.name = name;
        this.hMap = annuaire;
    }
/*    public void displayInfo() {
        System.out.println("\nMap display (HashMap) of " + name + ":");
         for(String key : this.hMap.keySet()) {
			String tel = this.hMap.get(key);
            System.out.println("\t---> name: " + key + " tel: " + tel);
		}
    }*/
	@Override
	public String toString() {
		return "Directory [name=" + name + ", hMap=" + hMap + "]";
	}
}