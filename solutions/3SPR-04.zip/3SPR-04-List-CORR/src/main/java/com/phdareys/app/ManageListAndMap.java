package com.phdareys.app;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.phdareys.bean.Directory;
import com.phdareys.bean.ManageList;

public class ManageListAndMap {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(
		       new String[] {"applicationContext.xml"});
				// display of all beans via this technic
		for (String beanName: appContext.getBeanDefinitionNames()) {
			if (appContext.getBean(beanName) instanceof Directory)
				System.out.println ((Directory) appContext.getBean(beanName));
			if (appContext.getBean(beanName) instanceof ManageList)
				System.out.println ((ManageList) appContext.getBean(beanName));
		}
        appContext.close();
	}

}
