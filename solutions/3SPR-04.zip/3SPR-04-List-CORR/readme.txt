SigmaWeb 2020-TD Java
------------------------------------------------------------------------------

1/ Th�me
-------------------
Spring+Maven+injection dans une liste et un annuaire 

2/ Todo
-------------
A/Listes:

- cr�er une classe m�tier prenant en param�tre une liste,(ex: sport: tennis, joueurs: Nadal, Federer, ...)
- injecter depuis le XML
- afficher le r�sultat

B/Annuaires:

- faire de m�me avec un annuaire (g�n�rer lien nom-t�l�phone, ex: dupont->0645672341, durant->0456781234, ...)

3/ R�sultats attendus
-------------
- Le contenu du fichier XML est affich�

6/ Bilan
-------------
Liste: exemple d'injection par constructeur:

<constructor-arg> 
<list> 
<value>Messi</value> 
<value>Neymar</value> 
<value>Ronaldo</value> 
</list> 
</constructor-arg>



Annuaire:

<map>
<entry key="Java " value="Good language"></entry>

