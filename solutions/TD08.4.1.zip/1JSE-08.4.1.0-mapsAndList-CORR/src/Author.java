

import java.util.HashSet;
import java.util.Set;

public class Author {
	private String firstName;
	private String lastName;
	private Set<Book> books;
	
	public Author(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.books = new HashSet<Book>();
	}

	// encapsulation 
	public void add(Book b) {
		books.add(b);
	}
	
	@Override
	public String toString() {
		return "Author [firstName=" + firstName + ", lastName=" + lastName + ", books=" + books + "]";
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public Set<Book> getBooks() {
		return books;
	}

	
}
