

public class Book {
	private String title;
	private int bDate;
	public Book(String title, int bDate) {
		super();
		this.title = title;
		this.bDate = bDate;
	}
	@Override
	public String toString() {
		return "Book [title=" + title + ", bDate=" + bDate + "]";
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getbDate() {
		return bDate;
	}
	public void setbDate(int bDate) {
		this.bDate = bDate;
	}
	
}
