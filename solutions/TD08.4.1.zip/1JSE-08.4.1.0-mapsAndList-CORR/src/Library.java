

import java.util.HashMap;
import java.util.Map;

public class Library {
	private String name;
	private Map<String, Author> authors = new HashMap<>();	// inout
	
	public Library(String name) {
		super();
		this.name = name;
	}
	public void add(Author a) {
		this.authors.put(a.getLastName(), a);
	}
	public Author find(String aName) {
		return this.authors.get(aName);
	}
	
	@Override
	public String toString() {
		return "Library [name=" + name + ", authors=" + authors + "]";
	}
	public String getName() {
		return name;
	}
	public Map<String, Author> getAuthors() {
		return authors;
	}

}
