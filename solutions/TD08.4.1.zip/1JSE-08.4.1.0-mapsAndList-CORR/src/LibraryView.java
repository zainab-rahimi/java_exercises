

import java.util.Set;

public class LibraryView {
	
	public String display (Author aut) {
		if (aut == null)
			return "Auteur inexistant";
		String mess = "Author: " + aut.getLastName() + ", " + aut.getFirstName() + "\n";
		int j=1;
		for (Book b:aut.getBooks()) {
			mess += "\t\t" + j + " Book: " + b.getTitle() + ", date: " + b.getbDate() + "\n";
			j++;
		}
		return mess;
		
	}
	public String display(Library lib) {
		String mess = "Library: " + lib.getName()+"\n";
		Set<String> authSet = lib.getAuthors().keySet();	// les cl�s(=tableau de String d'auteurs)
		int i=1;
		for (String k:authSet) {
			Author a = lib.getAuthors().get(k);
			mess += "\t" + i + " " + this.display(a);
			i++;		
		}
		return mess;
	}
	/*
	 * faire ceci:
	 * Biblioth: Alexandrie

	1 Balzac Honor�

                   Le P�re Goriot 1805

         2 Camus Albert

                    La peste 1960

                    L'�tranger 1956
	 */

}
