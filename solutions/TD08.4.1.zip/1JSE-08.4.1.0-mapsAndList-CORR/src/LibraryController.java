
public class LibraryController {
	public static void main(String[] args) {
		
		Library lib=new Library("FNAC");
		Author author=new Author ("Albert", "Camus");
		author.add(new Book ("La Peste", 1950));
		author.add(new Book ("L'�tranger", 1953));
		author.add(new Book ("Le mythe de Sysiphe", 1954));
		lib.add(author);
		
		author=new Author ("Blaise", "Cendrars");
		author.add(new Book ("Voyage au bout de la nuit", 1930));
		lib.add(author);
		
		//System.out.println (lib);
		// TODO : rajouter dans la library : suppression Author, trouver Author, affichage avec indentation, 
		// test sur doublon livre (utiliser un Set � la place du ArrayList)
		LibraryView libView=new LibraryView();
		System.out.println (libView.display(lib));
		
		// rechercher et afficher un auteur
		String sAuteur="Camus";
		author = lib.find(sAuteur);
		System.out.println (libView.display(author));
		sAuteur = "Moli�re";
		author = lib.find(sAuteur);
		System.out.println (libView.display(author));
		
	}
}
