
public class DiceApp {

	public static void main(String[] args) {
			// r�le du main: injecter des valeurs
		int valOneDice = 6;	
		int valTwoDices = 7;
		int valThreeDices = 17;
		int valNDices = 11;

			// un d�, 6?
		ThrowDice die = new ThrowDice();
		int proba = die.run(1, 6);
			// rendu
		System.out.println ("1 d�, proba pour: " + valOneDice + " ~= " + proba + " %");		

			// deux d�s, 7?
		proba = die.run(2, valTwoDices);
		System.out.println ("2 d�s, proba pour: " + valTwoDices + " ~= " + proba + " %");		

			// trois d�s, 17?
		proba = die.run(3, valThreeDices);
		System.out.println ("3 d�s, proba pour: " + valThreeDices + " ~= " + proba + " %");
		
			// 5 d�s, 11
		proba = die.run(5, valNDices);
		System.out.println ("5 d�s, proba pour: " + valNDices + " ~= " + proba + " %");		
	}
}
