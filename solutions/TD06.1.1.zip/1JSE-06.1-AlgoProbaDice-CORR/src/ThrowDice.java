
public class ThrowDice {
	private final static int MIN=1;	// d�claration constantes MIN et MAX DE
	private final static int MAX=6;
	private final static int EXP_NB=100000;	// nb d'exp�riences
	
	/**
	 * 	retourne la proba (% entier) de trouver un nombre nb avec nb d�s
	 * @param int: nb d�s
	 * @param int: nb cherch� 
	 * @return int: la proba en % (arrondi)
	 */
	public int run(int diceNb, int selectedNb) {				// do the job
		int successNb = 0;
		switch (diceNb) {
			case 1 : // 1 d�
				for (int i=0; i < EXP_NB; i++) {
					if (selectedNb == myIntRandom(MIN, MAX))
						successNb ++;
				}
				break;
			case 2 : // 2 d�s!
				int d1 = 0; int d2 = 0;
				for (int i=0; i < EXP_NB; i++) {
					d1 = myIntRandom(MIN, MAX);
					d2 = myIntRandom(MIN, MAX);
					if (d1 + d2 == selectedNb)
						successNb ++;
				}
				break;
			default: 		// pour n d�s!
				int d=0;
				for (int i=0; i < EXP_NB; i++) {
					int tot=0;
					for (int j=0; j < diceNb; j++) {
						d = myIntRandom(MIN, MAX);
						tot += d;
					}
					if (tot == selectedNb)
						successNb ++;
				}
		}

		return (int) (100* successNb / EXP_NB);	// proportion (cast�e en int)
	}

	// random int between min and max (inclusive)
	private int myIntRandom(int min, int max) {
		int val= new java.util.Random().nextInt((max - min) + 1) + min;
				//System.out.println (val);
		return val;
	}

}
