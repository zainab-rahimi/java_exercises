package com.phdareys.shop.view;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.phdareys.shop.entity.Order;
import com.phdareys.shop.entity.ProductSet;

public class OrderView extends JFrame {
	private static final long serialVersionUID = 1L;

	public void display(Order order) {
		// todo!!!
		System.out.println (order);
		setTitle("Customer: " + order.getCustomer() + ", Order n: " + order.getRef());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		String[] header = {"Product", "Nb", "lTot"};
		int i = 0;
		String[][] data = new String[order.getProds().size()][header.length] ;
		for (ProductSet pSet : order.getProds() ) {
			int j=0;
			data[i][j++] = pSet.getProd().toString(); 
			data[i][j++] = Integer.toString(pSet.getNb());
			data[i][j++] = Integer.toString(pSet.getPrice());
			i++; 			
		}
		JTable tab = new JTable(data, header);
		this.getContentPane().add(tab.getTableHeader(), BorderLayout.NORTH);
		this.getContentPane().add(tab, BorderLayout.CENTER);
		this.getContentPane().add(new JTextField ("Total: " + order.getAmount() + " �"), BorderLayout.SOUTH);
		pack();
		setVisible (true); 

	}

}
