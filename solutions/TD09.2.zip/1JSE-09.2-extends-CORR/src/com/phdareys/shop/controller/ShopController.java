package com.phdareys.shop.controller;

import com.phdareys.shop.entity.Order;
import com.phdareys.shop.entity.ProductSet;
import com.phdareys.shop.entity.bean.Harness;
import com.phdareys.shop.entity.bean.Product;
import com.phdareys.shop.entity.bean.Rope;
import com.phdareys.shop.entity.bean.Shoe;
import com.phdareys.shop.view.OrderView;

public class ShopController {

	public static void main(String[] args) {
		Order orders[]= new Order[] {
				new Order(
						"Paul",
						new ProductSet[] {
								new ProductSet  (3, 
										new Rope("R0001", 150, "BealComp","Beal", 80, "blue")),
								new ProductSet  (2, 
										new Shoe("S0002", 60, "Mago", "Scarpa", 8)),
								new ProductSet  (2, 
										new Harness("H0002", 50, "Prof", "Beal", 200)),
						}),
				new Order(
						"Elsa",
						new ProductSet[] {
								new ProductSet  (4, 
										new Rope("R0003", 180, "adrenalin","Edelrid", 70, "green")),
						}),		
		};

		for (Order order:orders) {
			order.run();	
			new OrderView().display(order);
		}

	}

}
