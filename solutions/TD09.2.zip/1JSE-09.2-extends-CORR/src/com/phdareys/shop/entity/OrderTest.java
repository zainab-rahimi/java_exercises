package com.phdareys.shop.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.phdareys.shop.entity.bean.Rope;

class OrderTest {

	@Test
	void test() {
		Order o = new Order(
				"Elsa",
				new ProductSet[] {
						new ProductSet (4, 
								new Rope("R0003", 180, "adrenalin","Edelrid", 70, "green")),
				});
		o.run();
		if (o.getAmount() != 720 || ! o.getCustomer().equalsIgnoreCase("Elsa")) {
			fail("Test1 not ok!!!");
		}
	}
	@Test
	void test2() {
		Order o = new Order(
				"Elsa",
				new ProductSet[] {
						new ProductSet (3, 
								new Rope("R0003", 180, "adrenalin","Edelrid", 70, "green")),
				});
		o.run();
		if (o.getAmount() != 540 || ! o.getCustomer().equalsIgnoreCase("Elsa")) {
			fail("Test2 not ok!!!");
		}
	}

}
