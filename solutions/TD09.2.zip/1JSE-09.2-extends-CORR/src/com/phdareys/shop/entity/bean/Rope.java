package com.phdareys.shop.entity.bean;

public class Rope extends Product {
	private int length;
	private String color;
	
	public Rope(String ref, int price, String name, String brand, int length, String color) {
		super(ref, price, name, brand);
		this.length = length;
		this.color = color;
	}

	@Override
	public String toString() {
		return super.toString() + ", Rope [length=" + length + ", color=" + color + "]";
	}
	
}
