package com.phdareys.shop.entity.bean;

public class Quickdraw extends Product {

	private int length;
	protected Quickdraw(String ref, int price, String name, String brand) {
		super(ref, price, name, brand);
		// TODO Auto-generated constructor stub
	}



}
