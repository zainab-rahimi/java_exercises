package com.phdareys.shop.entity;

import com.phdareys.shop.entity.bean.Product;

public class ProductSet {
	private int nb;	// to help managing set of Products!
	private Product prod;
	private int price;	// prix interm�diaire
	
	public ProductSet(int nb, Product prod) {
		super();
		this.nb = nb;
		this.prod = prod;
		this.price = 0; // prix "de la ligne" initialis�
	}
	
	public void run() {
		this.price = nb*prod.getPrice(); // prix "de la ligne"	
	}
	
	public int getPrice() {
		return price;
	}
	public int getNb() {
		return nb;
	}
	public Product getProd() {
		return prod;
	}
	
	@Override
	public String toString() {
		return "ProductSet [nb=" + nb + ", prod=" + prod + ", linePrice=" + price + "]";
	}
}
