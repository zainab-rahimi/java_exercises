package com.phdareys.shop.entity.bean;

public class Product {
	protected String ref;
	protected int price;
	protected String name;
	protected String brand;
	
	protected Product(String ref, int price, String name, String brand) {
		super();
		this.ref = ref;
		this.price = price;
		this.name = name;
		this.brand = brand;
	}

	public int getPrice() {
		return price;
	}

	@Override
	public String toString() {
		return "Product [ref=" + ref + ", price=" + price + ", name=" + name + ", brand=" + brand + "]";
	}		
	
}
