package com.phdareys.shop.entity.bean;

public class Harness extends Product {
	private int weight;

	public Harness(String ref, int price, String name, String brand, int weight) {
		super(ref, price, name, brand);
		this.weight = weight;
	}

	@Override
	public String toString() {
		return super.toString() + ", Harness [weight=" + weight + "]";
	}
	
}
