package com.phdareys.shop.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Order {
	private String ref = null;	// out
	private List<ProductSet> prodsSets = null;	// variable
	private int amount = 0;		// out
	private String customer = null;
	
	private static int orderNum = 0;	// necessary for ref number
	
	public Order() {
		super();
		orderNum ++;
		this.setRef();
		this.prodsSets = new ArrayList<ProductSet>();
	}
	public Order(String customer, ProductSet[] productsSet ) {
		this();
		this.customer = customer;
		for (ProductSet pSet:productsSet)
			this.add(pSet);
	}
	
	public void add( ProductSet pSet) {
		this.prodsSets.add(pSet);		// rajout � la liste
	}
	
	public  ProductSet del( int index) {
		return this.prodsSets.remove(index);		// del
	}
	
	public void run () {	// calcul du prix de la commande
		for (ProductSet pSet:prodsSets) {	// parcours de toute la liste
			pSet.run(); // calcul produit ligne	
			this.amount += pSet.getPrice();		// prix total
		}	
	}		
	
	public String getRef() {
		return ref;
	}
	public List<ProductSet> getProds() {
		return prodsSets;
	}
	public int getAmount() {
		return amount;
	}
	public static int getOrderNum() {
		return orderNum;
	}
	public String getCustomer() {
		return customer;
	}
	@Override
	public String toString() {
		return "Customer: " + customer + " Order [ref=" + ref + ", prods=" + prodsSets + ", amount=" + amount + "]";
	}

	private void setRef() {
		//  2021-05-19-00012  
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		this.ref = format.format(date) + "_" + String.format( "%05d", orderNum);
	}

}
