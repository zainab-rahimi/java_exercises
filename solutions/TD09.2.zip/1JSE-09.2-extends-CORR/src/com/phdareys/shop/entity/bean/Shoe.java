package com.phdareys.shop.entity.bean;

public class Shoe extends Product {
	private int size;

	public Shoe(String ref, int price, String name, String brand, int size) {
		super(ref, price, name, brand);
		this.size = size;
	}

	@Override
	public String toString() {
		return super.toString() + " Shoe [size=" + size + "]";
	}
	
}
