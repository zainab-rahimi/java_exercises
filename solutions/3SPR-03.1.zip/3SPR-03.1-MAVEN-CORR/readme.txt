SigmaWeb 2021-TD Java et Spring
------------------------------------------------------------------------------

CDC:
----
- Il s'agit de calculer la mensualit� correspondant � un emprunt et le co�t de l'op�ration
- on a donc en entr�e: 
montant, dur�e en mois et taux 
(ex: 100000, 120, 3.5) (et en sortie la mensualit� et le co�t de l'op�ration)
- cf formule jointe