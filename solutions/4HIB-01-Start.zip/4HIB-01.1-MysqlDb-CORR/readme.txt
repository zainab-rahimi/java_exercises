SigmaWeb 2021-TD Java
------------------------------------------------------------------------------

1/ Th�me
-------------------
Projet simple Hibernate/Maven/Mysql

2/ Todo
-------------
- ins�rer un employ� (id, firstName, lastName)
- lire un employ� (d'abord inexistant puis existant)
- d�truire un employ�

- ensuite s'organiser pour �tre conforme aux principes MVC 
(faire une couche repository ou dao pour 'all�ger' le controller)
    
3/ R�sultats attendus
-------------
- l'insertion est accompagn�e de trace, on visualise l'insertion dans l'utilitaire 
- de m�me pour la lecture on constate que l'id lu n'existe pas

    
4/ Notice d'install
-------------
 - cr�er la DB Mysql
 - cr�er le fichier POM
 - param�trer hibernate.cfg (cf tuto)
 
 
5/ Autres solutions, cas d�grad�
-------------
 
6/ Bilan
-------------
Avec Hibernate, pas besoin d'�crire directement le code SQL (insert, select...)

