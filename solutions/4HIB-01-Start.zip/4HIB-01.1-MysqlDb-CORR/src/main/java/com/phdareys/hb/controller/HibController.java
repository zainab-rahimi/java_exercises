package com.phdareys.hb.controller;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
//import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
//import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Root;

import org.hibernate.Session;    
import org.hibernate.Transaction;
//import org.hibernate.criterion.Restrictions;

import com.phdareys.bean.Employee;
import com.phdareys.hb.service.HibernateTool;

public class HibController {    
	public static void main(String[] args) {    
		try {
			Session session = HibernateTool.getSession();
				// d�marrage transaction
			Transaction t = session.beginTransaction(); 
				// insertion 
			session.save(new Employee(30, "Georges", "Clooney"));  
			session.save(new Employee(40, "Leonardo", "Di Caprio"));  
			session.save(new Employee(50, "Nicole", "Kidman"));  
				// tentative de lecture
			Employee e = (Employee)session.get(Employee.class, 50); 
			if(e != null) 
				System.out.println("\nEmployee Record is: " + e);
				
				// tentative de delete
			session.delete((Employee)session.get(Employee.class, 30)); 

			// Tous les Employes 
			CriteriaQuery<Employee> criteriaQuery = session.getCriteriaBuilder().createQuery(Employee.class);
			criteriaQuery.from(Employee.class);
			List<Employee> employees = session.createQuery(criteriaQuery).getResultList();
			employees.forEach(System.out::println);

			// avec Hibernate filtrer les emp dont l'id est > 42: �a marche mais c'est deprecated
			// bonne m�thode: avec JPA 
			CriteriaQuery<Employee> criteriaQuery2 = session.getCriteriaBuilder().createQuery(Employee.class);
			Root<Employee> eRoot = criteriaQuery2.from(Employee.class);
			criteriaQuery2.select(eRoot);
			criteriaQuery2.where(session.getCriteriaBuilder().greaterThanOrEqualTo(eRoot.get("id"),42));
			employees = session.createQuery(criteriaQuery2).getResultList();
			employees.forEach(System.out::println);
			
			likeFilter (session, employees, "K%");
			t.commit();  // validation transaction
				// fermeture usine+session
			HibernateTool.close();
		}
		catch (Exception e) {
			System.out.println ("Erreur hibernate ");
		}
	}  
	
	static void likeFilter(Session session, List<Employee> employees, String likeFilter ) {
			// exemple de codage: faire un like
			// criteria Builder = le point d'entr�e
		CriteriaBuilder cb = session.getCriteriaBuilder();
			// CriteriaQuery = la commande
		CriteriaQuery<Employee> criteriaQuery = cb.createQuery(Employee.class);
			// le root (ce qui est issu du "from")
		Root<Employee> eRoot = criteriaQuery.from(Employee.class);
			// rajout du "where" et le filtre (ici "lastname" commence par "K")
		criteriaQuery
			.select(eRoot)
			.where(cb.like(eRoot.get("lastName"),"K%"));
			// ex�cution et r�cup liste
		employees = session
				.createQuery(criteriaQuery)
				.getResultList();
			// affichage
		employees.forEach(System.out::println);
		
	}
}