package com.phdareys.hb.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.phdareys.bean.Employee;

public class EmployeeService {
	
	public void save(Employee emp) {
		Session session = HibernateTool.getSession();
		// d�marrage transaction
		Transaction t = session.beginTransaction(); 
		// insertion 
		session.save(emp);  
		// validation
		t.commit();

	}

}
