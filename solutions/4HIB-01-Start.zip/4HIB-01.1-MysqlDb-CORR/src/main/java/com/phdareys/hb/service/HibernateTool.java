package com.phdareys.hb.service;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateTool {
	
	private static final String HIB_CFG_FILE="hibernate.cfg.xml";
	
	private static SessionFactory sessionFactory = null;
	private static Session session = null;
	
	static{	// gestion du Singleton Pattern
		try{
			//Creation d'un ServiceRegistry avec le fichier de config Hibernate
			StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().
					configure(HIB_CFG_FILE).build(); 
			// mise en place des data et de la partie "usine"
			Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
			// ouverture session
			sessionFactory = meta.getSessionFactoryBuilder().build();  

		}catch (Exception e) {
			System.err.println("Session cannot be opened: " + e.getMessage());
			System.exit(1);
		}	
	}

	public static Session getSession() {
		// ouverture transaction s�curis�e
		session = sessionFactory.openSession();
		return session;
	}

	public static void close() { // on ferme tout
		try {
			session.close();
			sessionFactory.close();
		}catch (Throwable ex) {
			System.err.println("Session cannot be closed: " + ex);
			throw new ExceptionInInitializerError(ex);
		}	
	}
}
