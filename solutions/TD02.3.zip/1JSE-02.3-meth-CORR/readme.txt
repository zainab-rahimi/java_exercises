Il est n�cessaire de d�couper le code en m�thodes (fonctions) appel�es � la base par le main.

La syntaxe est la suivante (cf doc <basesJava>):

[static] [public/private] <typeRetour> nomMethode (<typePar1> par1, ...) {

          ...

          return <quelqueChoseDuTypeRetour>

}

TD: 1JSE-02.3-Fct
-> afficher la somme des entiers multiples de 3 allant jusqu'� une certaine valeur et d�marrant avec une valeur 

(ex: si valD�marrage=1 et valFinale=14, calculer 3+6+9+12) ?

Bilan : 

- plusieurs solutions possibles, examiner sp�cifiquement le cas de la fonction r�cursive.

