package com.phdareys.emp.model;

public class Employee {
		// 1.0/ class constants
	private static final int MONTH_NB = 12;
	private static final float TAX_PERCENT = 0.9f;
		// 1.1/ attributes (IN mode) ***
	private String firstName="";
	private String lastName="";
	private String firm="";
	private int age=0;
	private int mSal=0;
		// 1.2/ attributes (OUT mode): year cost ********
	private int yCost;	
	
		// 2/ constructor(s): with IN attributes mainly
	public Employee(String firstName, String lastName, String firm, int age, int mSal) {
		super();
		this.firstName = firstName;
		this.lastName = lastName.toUpperCase();
		this.firm = firm;
		this.age = age;
		this.mSal = mSal;
		
		this.yCost = 0;	// todo!!
	}

		// 3/ external methods: do the job!
	public void run() {
		this.setyCost((int) (MONTH_NB *  (1 + TAX_PERCENT) * mSal));		
	}
	
	// 4/ getter/setter
	// 5/ private methods
	private void setyCost(int yCost) {
		this.yCost = yCost;
	}

	// used in debug mode -> render of a complex object
	@Override
	public String toString() {
		return "Employee [firstName=" + firstName + ", lastName=" + lastName + ", firm=" + firm + ", age=" + age
				+ ", mSal=" + mSal + ", yCost=" + yCost + "]";
	}

}
