package com.phdareys.emp.controller;

import com.phdareys.emp.model.Employee;
import com.phdareys.emp.view.EmployeeView;

public class EmployeeController {

	public static void main(String[] args) {
			// init : inject data into model
		Employee emp = new Employee ("Paul", "Durand", "Free", 30, 2000);
			// use model to do the job
		emp.run();
			// view result from model
		new EmployeeView(emp);
	}

}
