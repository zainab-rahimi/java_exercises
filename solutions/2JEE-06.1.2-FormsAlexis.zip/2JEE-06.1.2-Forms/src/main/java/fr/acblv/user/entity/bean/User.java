package fr.acblv.user.entity.bean;

public class User {
	private String firstName;
	private String lastName;
	private int age;
	
	private Category category;
	
	public User(String firstName, String lastName, int age) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	public Category getCategory() {
		return category;
	}

	public Category run() {
		if(age >= Category.YOUNG.getMin() && age <= Category.YOUNG.getMax()) {
			return category = Category.YOUNG;
		}
		else if (age >= Category.ADULT.getMin() && age <= Category.ADULT.getMax()){
			return category = Category.ADULT;
		}
		else {
			category = Category.SENOIR;
		}
		return category;
	}

	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + ", category=" + category
				+ "]";
	}
	
	
	
}
