package fr.acblv.user.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.acblv.user.entity.bean.User;
import fr.acblv.user.form.UserForm;

/**
 * Servlet implementation class UserController
 */
@WebServlet("")
public class FormController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String URL_FWD = "/WEB-INF/FormView.jsp";
		this.getServletContext().getRequestDispatcher(URL_FWD).forward( request, response );
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("first_name");
		String lastName = request.getParameter("last_name");
		int age = Integer.parseInt(request.getParameter("age"));
		UserForm uf = new UserForm();
		if (uf.checkValidity(firstName, lastName, age).isEmpty()) {
			User u = new User(firstName, lastName, age);
			u.run();
			request.setAttribute("user", u);
			String URL_VIEW = "/WEB-INF/UserView.jsp";
			this.getServletContext().getRequestDispatcher(URL_VIEW).forward( request, response );
		}
		else {
			request.setAttribute("errors", uf.getErrors());
			request.setAttribute("first_name", firstName);
			request.setAttribute("last_name", lastName);
			request.setAttribute("age", age);
			doGet(request, response);
		}
		
		
		
	}

}
