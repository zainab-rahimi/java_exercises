package fr.acblv.user.form;

import java.util.HashMap;
import java.util.Map;

public class UserForm {
	private Map<String, String> errors;
	public Map<String, String> checkValidity(String firstName, String lastName, int age) {
		errors = new HashMap<String, String>();
		if(firstName.length() < 3) {
			errors.put("first_name", "Nombre de caractère inférieur à 3 !");
		}
		if (lastName.length() < 3) {
			errors.put("last_name", "Nombre de caractère inférieur à 3 !");
		}
		if (age > 100) {
			errors.put("age", "Age supérieur à 100");
		}
		return errors;
	}
	public Map<String, String> getErrors() {
		return errors;
	}
	
}
