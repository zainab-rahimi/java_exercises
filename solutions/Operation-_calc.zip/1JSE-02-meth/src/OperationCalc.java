
public class OperationCalc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// We invoke the method inside the main, initialization of method parameters inside the main method

		int valDemarrage =3;
		int valFinale = 23;
		// For printing the result, call the method inside the System.out.println()
		System.out.println(sum(valDemarrage, valFinale));

	}

	public static int sum(int valDemarrage, int valFinale) {
		int result = 0;
		for (int i = valDemarrage; i < valFinale + 1; i+= 3)
			if (i%3 == 0) {
				result = result + i;
				System.out.println(i);
			}
		return result;
	}	
}
