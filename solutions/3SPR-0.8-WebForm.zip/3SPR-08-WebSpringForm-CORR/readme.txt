SigmaWeb 21-TD Ja20va
------------------------------------------------------------------------------

1/ Thème
-------------------
Web+Maven+Spring+formulaires

2/ Todo
-------------
- créer un index qui pointe sur une page de réservation
- cette page affiche un formulaire (prénom/nom/genre (radio), repas (checkbox))
- la validation provoque l'affichage de la réservation

- Gérer les erreurs:
Par ex le nom et le prénom ne sont pas vides!

Pour cela on a le 'BindingResult' (final BindingResult bResult) à passer dans la méthode contrôleur

- Pour spécifier les erreurs:
bResult.rejectValue("firstName","Error"); 
=> signifie par exemple une erreur sur ce champ et pointe sur le label :
Error.reservation.firstName=Fill field Firstname please! d'un fichier de propriétés!!
    
- pour vérifier s'il y a des erreurs:
bResult.hasErrors() ...
3/ Résultats attendus
-------------
- les paramètres de saisie sont tous récupérés
    
4/ Notice d'install
-------------
Pour simplifier: mettre uniquement nom/prénom dans la réservation
Ne pas traiter les erreurs

5/ Autres solutions, cas dégradés
-------------

6/ Bilan
-------------
Avec Spring:
- le code Servlet est épuré 
- les annotations sont grandement utilisées (@controller, @requestAttribute, ...)
- la jsp intègre de nouvelles balises qui facilitent la gestion du formulaire (<form:*>)
- on peut rajouter des ressources au serveur (css, js, images)
- on peut utiliser des fichiers de propriétés pour les erreurs/l'interface
- on utilise de nouveaux services qui permettent de gérer les erreurs de formulaires (reject), 
la transmission du modèle (modeleAttribute)

Nota: 
- dans la jsp, nouvelles balises:
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
...
<form:form action="submitForm" modelAttribute="reservation">
....		
		First name: <form:input path="firstName" />	
		<form:errors path="firstName" cssClass="error" />	
		<br>
...
- dans le controller, passer le modele:
...
		Reservation res=new Reservation();
		model.addAttribute("reservation", res);

Nota:
- 1/ configurer toutes les jsp:
1.1/ contenu de mon web.xml

<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="http://java.sun.com/xml/ns/javaee"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http//java.sun.com/xml/ns/javaee http://java.sun.com/xml/ns/javaee/web-app_3_0.xsd"
	version="3.0">
	<jsp-config>
		<jsp-property-group>
			<url-pattern>*.jsp</url-pattern>
			<include-prelude>/WEB-INF/taglibs.jsp</include-prelude>
		</jsp-property-group>
	</jsp-config>
</web-app>
1.2/ contenu de mon taglibs.jsp
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!-- TAG LIB PREFIX -->
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!-- STYLE SHEET -->
<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">


- 2/ gestion des ressources:
https://www.baeldung.com/spring-mvc-static-resources
