package com.phdareys.spr.form.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.phdareys.spr.form.bean.Employee;

@Controller
public class EmployeeController {
	
	@RequestMapping(value = "/employee", method = RequestMethod.GET)
    public ModelAndView showForm() {
        return new ModelAndView("employeeHome", "employee", new Employee());
    }

    @RequestMapping(value = "/addEmployee", method = RequestMethod.POST)
    public String submit(@Validated @ModelAttribute("employee")Employee employee, 
      BindingResult result, ModelMap model) {
        if (! this.checkValues(employee, result)) {
            return "employeeHome";
        }
        model.addAttribute("emp", employee);
        return "employeeView";
    }
    
    private boolean checkValues(Employee emp, BindingResult result) {
    	if (emp.getId() > 10) 
    		result.rejectValue("id", "Error");
    	if (emp.getName().length()<3) 
    		result.rejectValue("name", "Error");
//    	if (! emp.getContactNumber().contains("Contact")) 
//    		result.rejectValue("contactNumber", "Error");
    	
		return ! result.hasErrors();
    	
    }
}
