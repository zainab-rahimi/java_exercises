package com.phdareys.spr.form.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.phdareys.spr.form.bean.Reservation;

@RequestMapping("/reservation")
@Controller
public class ReservationController {
	
	@RequestMapping("/bookingForm")
	public String bookingForm(Model model)
	{		// association bean-model
		Reservation res=new Reservation();
		model.addAttribute("reservation", res);
			// lien jsp
		return "reservation-page";
	}
	
	@RequestMapping("/submitForm")
	public String submitForm(
			@ModelAttribute("reservation") 
				final Reservation res,	// objet réservation
				final BindingResult bResult)	// liaison, stockage erreurs
	{			// vérif data
		System.out.println (res);
				// vérif validité du formulaire
		this.checkForm(res, bResult);
		
		String jsp = "confirmation-form";
		if (bResult.hasErrors()) // erreur : réaffichage
			jsp  = "reservation-page";	// avec les erreurs traitées
				// si pas d'erreur, mapping de l'objet résultat
		return jsp;
	}
	
			// vérif en chaîne suivant CDC
	private void checkForm (final Reservation resrv, 
			final BindingResult bResult) {
		// exemple de contrôle : le prénom contient un 'a' et n'est pas vide
		if (resrv.getFirstName().isEmpty() || ! resrv.getFirstName().contains("a")) 
			bResult.rejectValue("firstName","Error");
		if (resrv.getLastName().isEmpty()) 
			bResult.rejectValue("lastName","Error");
			// ex contrôle métier : un homme ne peut réserver plus de 2 repas!!!
		if ((resrv.getGender().isEmpty()) || 
				(resrv.getGender().contains("M") && resrv.getFood().length > 2))
			bResult.rejectValue("food","Error");
	}
}
