
function hello () {
	alert ("Hello BGE!");
}
window.addEventListener("DOMContentLoaded", hello);
